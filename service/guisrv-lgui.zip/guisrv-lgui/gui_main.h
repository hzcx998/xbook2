#ifndef  __APP_GUI_MAIN_H__
#define  __APP_GUI_MAIN_H__

#include  <learninggui.h>


#ifdef	__cplusplus
extern  "C"
{
#endif

    int  paint_gui_main(void); 

    int  message_user_main_routine(/* GUI_MESSAGE */ void *msg);

#ifdef	__cplusplus
}
#endif

#endif  /* __APP_GUI_MAIN_H__ */
