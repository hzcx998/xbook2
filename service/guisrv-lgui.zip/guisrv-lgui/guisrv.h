#ifndef _GUISRV_H
#define _GUISRV_H

#include <sys/srvcall.h>

/* 当前服务的名字 */
#define SRV_NAME    "guisrv"

#endif  /* _GUISRV_H */