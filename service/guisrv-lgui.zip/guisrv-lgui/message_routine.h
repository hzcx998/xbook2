#ifndef  _APP_MESSAGE_ROUTINE_H
#define  _APP_MESSAGE_ROUTINE_H

#include  <learninggui.h>

    
#ifdef  __cplusplus
extern  "C"
{
#endif


    int  message_main_routine(/* GUI_MESSAGE *msg */ void *msg);


#ifdef  __cplusplus
}
#endif

#endif  /* _APP_MESSAGE_ROUTINE_H */
