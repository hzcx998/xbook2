#ifndef  __LGUI_APP_FONT_HEADER__
#define  __LGUI_APP_FONT_HEADER__
   
#ifdef  __cplusplus
extern  "C"
{
#endif

    extern  GUI_VAR_CONST  GUI_FONT  app_font; 

#ifdef  __cplusplus
}
#endif

#endif  /* __LGUI_APP_FONT_HEADER__ */
