#ifndef  _APP_WIN_FRAME3_H
#define  _APP_WIN_FRAME3_H

#include  <learninggui.h>

    
#ifdef  __cplusplus
extern  "C"
{
#endif


#ifdef  __cplusplus
}
#endif

#endif  /* _APP_WIN_FRAME3_H */
