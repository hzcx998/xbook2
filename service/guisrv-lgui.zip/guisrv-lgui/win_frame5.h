#ifndef  _APP_WIN_FRAME5_H
#define  _APP_WIN_FRAME5_H

#include  "learninggui.h"

 
#ifdef  __cplusplus
extern  "C"
{
#endif



#ifdef  __cplusplus
}
#endif

#endif  /* _APP_WIN_FRAME5_H */
