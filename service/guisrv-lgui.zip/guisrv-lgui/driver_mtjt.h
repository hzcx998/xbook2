#ifndef  __LGUI_DRIVER_MTJT_HEADER__
#define  __LGUI_DRIVER_MTJT_HEADER__


#include  <learninggui.h>


#ifdef    _LG_MTJT_
    
#ifdef  __cplusplus
extern  "C"
{
#endif

    int  register_mtjt(void);

#ifdef  __cplusplus
}
#endif

#endif  /* _LG_MTJT_ */

#endif  /* __LGUI_DRIVER_MTJT_HEADER__ */
