#ifndef  __LGUI_MONO_DISCRETE_FONT_ASCII__HEADER__
#define  __LGUI_MONO_DISCRETE_FONT_ASCII__HEADER__

#include  "learninggui.h"


#ifdef	__cplusplus
extern  "C"
{
#endif

    extern  GUI_DATA_CONST  MONO_DISCRETE_FONT  my_mono_discrete_ascii;

#ifdef	__cplusplus
}
#endif


#endif  /*__LGUI_MONO_DISCRETE_FONT_ASCII__HEADER__*/
