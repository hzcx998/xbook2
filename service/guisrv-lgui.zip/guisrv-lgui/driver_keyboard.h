#ifndef  __LGUI_DRIVER_KEYBOARD_HEADER__
#define  __LGUI_DRIVER_KEYBOARD_HEADER__


#include  <learninggui.h>


#ifdef    _LG_KEYBOARD_

#ifdef  __cplusplus
extern  "C"
{
#endif

    int  register_keyboard(void);

#ifdef  __cplusplus
}
#endif

#endif  /*  _LG_KEYBOARD_ */

#endif  /* __LGUI_DRIVER_KEYBOARD_HEADER__ */
