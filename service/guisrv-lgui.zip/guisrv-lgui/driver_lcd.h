#ifndef  __LGUI_DRIVER_LCD_HEADER__
#define  __LGUI_DRIVER_LCD_HEADER__

#include  <learninggui.h>


#ifdef  _LG_SCREEN_

#ifdef  __cplusplus
extern  "C"
{
#endif

    int  register_screen(void);

#ifdef  __cplusplus
}
#endif

#endif  /* _LG_SCREEN_ */

#endif  /* __LGUI_DRIVER_LCD_HEADER__ */
