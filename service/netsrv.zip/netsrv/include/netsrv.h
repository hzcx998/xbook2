
#ifndef __NETSRV_H
#define __NETSRV_H

/* 当前服务的名字 */
#define SRV_NAME    "netsrv"

void lwip_init_task(void);

#endif  /* __NETSRV_H */
