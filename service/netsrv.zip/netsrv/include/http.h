
#ifndef __HTTP_H
#define __HTTP_H

void http_server_init(void);
void echo_client_init(void);

#endif
